-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.27-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for project_mrderr
CREATE DATABASE IF NOT EXISTS `project_mrderr` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `project_mrderr`;

-- Dumping structure for table project_mrderr.items
CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(255) DEFAULT NULL,
  `item_name` varchar(255) NOT NULL,
  `dateandtime` datetime NOT NULL,
  `delivery_contact_person` varchar(255) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `serial_nr` int(11) DEFAULT NULL,
  `barcode_manufacturer` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table project_mrderr.items: ~4 rows (approximately)
INSERT INTO `items` (`id`, `barcode`, `item_name`, `dateandtime`, `delivery_contact_person`, `amount`, `price`, `serial_nr`, `barcode_manufacturer`) VALUES
	(1, 'CE309953957EE', '', '2023-10-12 10:37:00', '', 360, 0.00, 0, ''),
	(2, 'CE309953957EE', '', '2023-10-12 10:37:00', '', 360, 0.00, 0, ''),
	(3, '582941184CFD', 'tests', '2023-10-04 09:00:00', 'Roberts', 360, 2.00, 22252, '25248284trt'),
	(4, '582941184CFD', 'tests', '2023-10-04 09:00:00', 'Roberts', 360, 2.00, 22252, '25248284trt'),
	(5, '  CE440525078EE', 'burka', '2023-10-04 09:17:00', 'Ervins', 13, 2.00, 8248198, '25248284trt');

-- Dumping structure for table project_mrderr.login_attempts
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table project_mrderr.login_attempts: ~14 rows (approximately)
INSERT INTO `login_attempts` (`id`, `username`, `password`, `login_time`) VALUES
	(1, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:10:54'),
	(2, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:22:56'),
	(3, 'tests', '123', '2023-10-03 06:23:59'),
	(4, 'tests', '123', '2023-10-03 06:25:56'),
	(5, 'tests', '123', '2023-10-03 06:25:59'),
	(6, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:30:42'),
	(7, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:30:52'),
	(8, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:30:55'),
	(9, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:31:20'),
	(10, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:31:34'),
	(11, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:31:47'),
	(12, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:31:50'),
	(13, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:32:03'),
	(14, 'Swim_Mario', 'Gustins2005', '2023-10-03 06:32:05');

-- Dumping structure for table project_mrderr.removed_items
CREATE TABLE IF NOT EXISTS `removed_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(255) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `dateandtime` datetime DEFAULT NULL,
  `delivery_contact_person` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `serial_nr` varchar(255) DEFAULT NULL,
  `barcode_manufacturer` varchar(255) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table project_mrderr.removed_items: ~3 rows (approximately)
INSERT INTO `removed_items` (`id`, `barcode`, `item_name`, `dateandtime`, `delivery_contact_person`, `amount`, `price`, `serial_nr`, `barcode_manufacturer`, `total_price`) VALUES
	(1, '  CE440525078EE', 'burka', '2023-10-13 13:34:54', 'Ervins', 3, NULL, '8248198', '25248284trt', NULL),
	(2, '  CE440525078EE', 'burka', '2023-10-13 13:38:51', 'Ervins', 3, 2.00, '8248198', '25248284trt', 6.00),
	(3, '  CE440525078EE', 'burka', '2023-10-13 13:40:10', 'Ervins', 1, 2.00, '8248198', '25248284trt', 2.00);

-- Dumping structure for table project_mrderr.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `agree_terms` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table project_mrderr.users: ~7 rows (approximately)
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `agree_terms`) VALUES
	(1, 'Mariuss', 'Gustins', 'mariuss.gustins@outlook.com', 'Swim_Mario', '$2y$10$7SNWNpbIf67du.yoa2xccushlRzzAMws3yEkMgD8d3a.LuFAjL/Ty', 1),
	(2, 'Ervins', 'J', 'xxallihueyxx@gmail.com', 'tests', '$2y$10$6bcZ2StTV1AGTRXypoR0A.0Tgf5AMtU1RtI.qFrcqwvNgerZldPoy', 1),
	(3, 'PAtriks', 'Ozols', 'xxallihueyxx@gmail.com', 'mariussgustins', '$2y$10$pS8d9ZRCloT0Kr.87EqeK.vlzsUaOgArvo4hdpyAkHbdvBu6likwu', 1),
	(4, '', 'P', 'xxallihueyxx@gmail.com', 'tests2', '$2y$10$frWX4XqRiZk3OOhiyZey1uPcVD6OEeUojX/MBllXLYPUn2K1yzTBO', 1),
	(5, '', 'G', 'mariuss.gustins@outlook.com', 'user', '$2y$10$.BsVTlkRefzneWpUHPJkC.BYfXCs8.R/gw5O1raZ3okcn.HnZtGwC', 1),
	(6, 'Kristians', 'G', 'mariuss.gustins@outlook.com', 'user', '$2y$10$iI3q7oJilRqATbEWj/C/b.U6Ikr67NCuE0iuB/sCQi75K6c3nh2oa', 1),
	(7, 'Mariuss', 'Gustins', 'mariuss.gustins@outlook.com', 'xd', '$2y$10$VoBRXbUxNWAX7equ51cll.wTrj8d5ZnMbSvu/YnwPQCbu1.W2K.t2', 1),
	(8, 'Mariuss', 'Gustins', 'mariuss.gustins@outlook.com', 'reg', '$2y$10$cWhDK5r.pwwE/lYK2ncybex7jq.r5iqE76Q53s4wPVciOtUH2SKFm', 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
